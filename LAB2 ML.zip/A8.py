import pandas as pd

def main():
    df=pd.read_excel(
        r"C:\Users\likit\AppData\Local\Programs\Python\Python313\Lab Session Data.xlsx",
        sheet_name="thyroid0387_UCI"
    )
    print(df.isnull().sum())
main()
        
