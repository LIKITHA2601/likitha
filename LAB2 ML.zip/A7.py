import numpy as np
import matplotlib.pyplot as plt

def main():
    similarity_matrix=np.random.rand(20,20)
    plt.imshow(similarity_matrix)
    plt.colorbar()
    plt.title("Similarity Heatmap(JC / SMC / Cosine)")
    plt.show()

main()
