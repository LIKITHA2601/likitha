import numpy as np
from sklearn.neighbors import KNeighborsClassifier

def euclidean_distance(x1,x2):
    return np.sqrt(sum((a-b)**2 for a,b in zip(x1,x2)))

def knn_predict(X_train,y_train,X_test,k):
    predictions=[]
    for test_point in X_test:
        distances=[]
        for i in range(len(X_train)):
            dist=euclidean_distance(test_point,X_train[i])
            distances.append((dist,y_train[i]))
        distances.sort(key=lambda x:x[0])
        k_nearest=distances[:k]
        class_votes={}
        for _,label in k_nearest:
            class_votes[label]=class_votes.get(label,0)+1
        predicted_class=max(class_votes,key=class_votes.get)
        predictions.append(predicted_class)
    return predictions
X_train=np.array([[1,2],[2,3],[3,4],[6,7]])
y_train=np.array([0,0,0,1])
X_test=np.array([[7,8],[8,9]])
y_test=np.array([1,1])
k=3
own_predictions=knn_predict(X_train,y_train,X_test,k)
print("predictions using own kNN:",own_predictions)
sk_knn=KNeighborsClassifier(n_neighbors=k)
sk_knn.fit(X_train,y_train)
sk_predictions=sk_knn.predict(X_test)
print("predictions using Scikit-learn kNN:",sk_predictions)
print("\nComparision of results")
for i in range(len(X_test)):
    print(f"Test Vector {X_test[i]} -> Own kNN: {own_predictions[i]},"
          f"Package kNN: {sk_predictions[i]}")
    
