import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score
X_train=np.array([[1,2],[2,3],[3,4],[6,7]])
y_train=np.array([0,0,0,1])
X_test=np.array([[7,8],[8,9]])
y_test=np.array([1,1])
knn=KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,y_train)
y_pred=knn.predict(X_test)
print("predicted labels:",y_pred)
print("Actual labels:",y_test)
accuracy=accuracy_score(y_test,y_pred)
print("Accuracy on test set:",accuracy)
