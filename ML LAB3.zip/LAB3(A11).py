import numpy as np
import matplotlib.pyplot as plt
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

X_train=np.array([[1,2],[2,3],[3,4],[6,7],[7,8]])
y_train=np.array([0,0,0,1,1])

X_test=np.array([[4,5],[8,9]])
y_test=np.array([0,1])
knn_1=KNeighborsClassifier(n_neighbors=1)
knn_1.fit(X_train,y_train)
y_pred_1=knn_1.predict(X_test)
acc_1=accuracy_score(y_test,y_pred_1)
print("Accuracy with k=1 (NN):",acc_1)
knn_3=KNeighborsClassifier(n_neighbors=3)
knn_3.fit(X_train,y_train)
y_pred_3=knn_3.predict(X_test)
acc_3=accuracy_score(y_test,y_pred_3)
print("Accuracy with k=3(kNN):",acc_3)
max_k=len(X_train)
k_values=range(1,max_k+1)
accuracies=[]

for k in k_values:
    knn=KNeighborsClassifier(n_neighbors=k)
    knn.fit(X_train, y_train)
    y_pred=knn.predict(X_test)
    acc=accuracy_score(y_test,y_pred)
    accuracies.append(acc)
plt.plot(k_values,accuracies,marker='o')
plt.xlabel("value of k")
plt.ylabel("Accuracy")
plt.title("kNN Accuracy for Different values of k")
plt.xticks(k_values)
plt.grid(True)
plt.show()
