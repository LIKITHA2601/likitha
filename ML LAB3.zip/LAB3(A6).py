import numpy as np
from sklearn.model_selection import train_test_split
X=np.array([
    [1,2],[2,3],[3,4],
    [6,7],[7,8],[8,9]
    ])
y=np.array([0,0,0,1,1,1])
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=42)
print("X_train:\n",X_train)
print("y_train:",y_train)
print("X_test:",X_test)
print("y_test:",y_test)
