from sklearn.neighbors import KNeighborsClassifier
X_train=[[1,2],[2,3],[3,4],[6,7]]
y_train=[0,0,0,1]
X_test=[[7,8],[8,9]]
y_test=[1,1]
neigh=KNeighborsClassifier(n_neighbors=3)
neigh.fit(X_train,y_train)
accuracy=neigh.score(X_test,y_test)
print("Accuracy of kNN classifier:",accuracy)
