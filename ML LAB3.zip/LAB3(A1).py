import math
import numpy as np
def dot_product(A, B):
    if len(A) != len(B):
        raise ValueError("Vectors must be of same dimension")
    result = 0
    for i in range(len(A)):
        result += A[i] * B[i]
    return result


def euclidean_norm(A):
    sum_sq = 0
    for x in A:
        sum_sq += x ** 2
    return math.sqrt(sum_sq)

import numpy as np

A = np.array([1, 2, 3])
B = np.array([4, 5, 6])
A1=dot_product(A,B)
B1=np.dot(A,B)
print("Dot Product (own):", dot_product(A, B))
print("Norm A (own):", euclidean_norm(A))
print("Norm B (own):", euclidean_norm(B))
A2=euclidean_norm(A)
B2=np.linalg.norm(A)
print("Dot Product (numpy):", np.dot(A, B))
print("Norm A (numpy):", np.linalg.norm(A))
print("Norm B (numpy):", np.linalg.norm(B))

if A1==B1:
    print("hence verified!,dot_product function calculates the result which is the same as np.dot function")

if A2==B2:
    print("hence verified!, euclidean_norm function results the same value as np.linalg.norm function,simalrly the norm of B is also verified")    
