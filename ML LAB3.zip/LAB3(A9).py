from sklearn.neighbors import KNeighborsClassifier
X_train=[[1,2],[2,3],[3,4],[6,7]]
y_train=[0,0,0,1]
X_test=[[7,8],[8,9]]
neigh=KNeighborsClassifier(n_neighbors=3)
neigh.fit(X_train,y_train)
predicted_classes=neigh.predict(X_test)
print("predicted class labels for test set",predicted_classes)
test_vect=[[7,8]]
predicted_class=neigh.predict(test_vect)
print("predicted class for test vector",test_vect,":",predicted_class)
