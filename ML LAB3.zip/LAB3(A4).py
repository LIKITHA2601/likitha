import numpy as np
import matplotlib.pyplot as plt
def minkowski_distance(x,y,p):
    return sum(abs(a-b)**p for a,b in zip(x,y))**(1/p)
vec1=[1,2,3,4,5]
vec2=[5,4,3,2,1]
p_values=range(1,11)
distances=[minkowski_distance(vec1,vec2,p) for p in p_values]
plt.plot(p_values,distances,marker='o')
plt.title("Minkoski Distance vs p")
plt.xlabel("p (Order of Minkowski Distance")
plt.ylabel("Distance")
plt.grid(True)
plt.show()
