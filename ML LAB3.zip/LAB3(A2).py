import numpy as np
import math
def mean(data):
    return sum(data)/ len(data)
def variance(data):
    m=mean(data)
    return sum((x-m)**2 for x in data)/len(data)
def standard_deviation(data):
    return math.sqrt(variance(data))

def class_centroid(class_data):
    class_data=np.array(class_data)
    return np.mean(class_data,axis=0)
def intraclass_spread(class_data):
    class_data=np.array(class_data)
    return np.std(class_data, axis=0)
def interclass_distance(class1, class2):
    c1=class_centroid(class1)
    c2=class_centroid(class2)
    return np.linalg.norm(c1-c2)

class1=[
    [1,2],
    [2,3],
    [3,4]]
class2=[
    [6,7],
    [7,8],
    [8,9]]
print("centroid of class 1:",class_centroid(class1))
print("centroid of class2:",class_centroid(class2))
print("Intraclass spread(Class 1):",intraclass_spread(class1))
print("Intraclass spread(Class 2):",intraclass_spread(class2))
print("Interclass distance:",interclass_distance(class1,class2))
