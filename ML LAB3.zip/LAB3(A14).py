import numpy as np
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import accuracy_score

X_train=np.array([[1,2],[2,3],[3,4],[6,7],[7,8]])
y_train=np.array([0,0,0,1,1])
X_test=np.array([[4,5],[8,9]])
y_test=np.array([0,1])
k=3
knn=KNeighborsClassifier(n_neighbors=k)
knn.fit(X_train,y_train)
y_pred_knn=knn.predict(X_test)
acc_knn=accuracy_score(y_test,y_pred_knn)

print("kNN predictions;",y_pred_knn)
print("kNN Accuracy:",acc_knn)

def train_matrix_inversion(X,y):
    X_bias=np.c_[np.ones(X.shape[0]),X]
    W=np.linalg.pinv(X_bias) @ y
    return W

def predict_matrix_inversion(X,W):
    X_bias=np.c_[np.ones(X.shape[0]),X]
    
    y_pred_continuous=X_bias @ W
    y_pred_class=(y_pred_continuous>=0.5).astype(int)
    return y_pred_class

W=train_matrix_inversion(X_train,y_train)
y_pred_mi=predict_matrix_inversion(X_test,W)
acc_mi=accuracy_score(y_test,y_pred_mi)
print("\nMatrix Inversion Predictions:",y_pred_mi)
print("Matrix Inversion Accuracy:",acc_mi)

print("\n--- Performance Comparison---")
print(f"kNN Accuracy :{acc_knn}")
print(f"Matrix Inversion Accuracy:{acc_mi}")

