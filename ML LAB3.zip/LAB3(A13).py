import numpy as np
from sklearn.neighbors import KNeighborsClassifier

X_train=np.array([[1,2],[2,3],[3,4],[6,7],[7,8]])
y_train=np.array([0,0,0,1,1])
X_test=np.array([[4,5],[8,9]])
y_test=np.array([0,1])
knn=KNeighborsClassifier(n_neighbors=3)
knn.fit(X_train,y_train)
y_train_pred=knn.predict(X_train)
y_test_pred=knn.predict(X_test)
def confusion_matrix_own(y_true,y_pred):
    TP=FP=TN=FN=0

    for yt,yp in zip(y_true,y_pred):
        if yt==1 and yp==1:
            TP+=1
        elif yt==0 and yp==0:
            TN+=1
        elif yt==0 and yp==1:
            FP+=1
        elif yt==1 and yp==0:
            FN+=1

    return [[TN,FP],
            [FN, TP]]

def accuracy_own(y_true,y_pred):
    correct=sum(1 for yt,yp in zip(y_true,y_pred) if yt==yp)
    return correct/ len(y_true)

def precision_own(y_true,y_pred):
    cm=confusion_matrix_own(y_true,y_pred)
    TP=cm[1][1]
    FP=cm[0][1]
    return TP/(TP+FP) if (TP +FP) !=0 else 0

def recall_own(y_true,y_pred):
    cm=confusion_matrix_own(y_true, y_pred)
    TP=cm[1][1]
    FN=cm[1][0]
    return TP/(TP+FN) if (TP+FN) != 0 else 0

def fbeta_score_own(y_true,y_pred,beta=1):
    precision=precision_own(y_true,y_pred)
    recall=recall_own(y_true,y_pred)
    if precision+recall==0:
        return 0
    beta_sq=beta**2
    return (1+beta_sq)*(precision *recall)/(beta_sq* precision+recall)

print("TRAINING DATA RESULTS:")
print("Confusion Matrixz;",confusion_matrix_own(y_train,y_train_pred))
print("Accuracy:",accuracy_own(y_train,y_train_pred))
print("Precision :",precision_own(y_train,y_train_pred))
print("Recall:",recall_own(y_train,y_train_pred))
print("F1-Score:",fbeta_score_own(y_train,y_train_pred))

print("\nTEST DATA RESULTS")
print("Confusion Mtarix:",confusion_matrix_own(y_test,y_test_pred))
print("Accuracy:",accuracy_own(y_test,y_test_pred))
print("Precision:",precision_own(y_test,y_test_pred))
print("recall:",recall_own(y_test,y_test_pred))
print("F1-Score:",fbeta_score_own(y_test,y_test_pred))


      
