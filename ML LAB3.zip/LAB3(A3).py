import numpy as np
import matplotlib.pyplot as plt
feature_data=np.array([12,15,14,16,18,19,21,22,23,24,25,26,28,30,32,35,36,38,40,42])

bins=5
hist_values,bin_edges=np.histogram(feature_data, bins=bins)
print("histogram values:",hist_values)
print("bin  edges:",bin_edges)
